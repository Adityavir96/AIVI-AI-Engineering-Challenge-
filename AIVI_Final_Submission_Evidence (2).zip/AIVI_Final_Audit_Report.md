
# AIVI AI ENGINEERING CHALLENGE
## LLM Audit and Pipeline Optimization

### 1. Project Overview

This project demonstrates an AI-powered resume matching
system using Python, Gemini API and Pydantic.

The system compares resume information against a job
description and produces a structured JSON evaluation.

### 2. Technology Stack

- Python
- Google Gemini API
- Pydantic
- PyMuPDF
- Tesseract OCR
- Google Colab

### 3. Output Schema

- match_score: Integer from 0 to 100
- top_strengths: List of strings
- missing_skills: List of strings
- summary: Exactly two sentences

### 4. Resume Evaluation

An earlier successful Gemini execution returned a
match score of 72/100.

The evaluation identified Python, SQL, Git and React
as strengths, with REST API and Django/Flask experience
as missing skills.

The score is model-generated and may vary between runs.

### 5. Adversarial Testing

Prompt Injection:
An earlier Gemini test returned a score of 45.

Hinglish Technical Content:
An earlier Gemini test returned a score of 55.

Missing Skills:
Not completed because the Gemini free-tier quota
was exhausted.

### 6. OCR Testing

JPEG resume OCR was successfully executed using
Tesseract OCR.

The extracted text contained 2932 characters.

Some formatting and characters were imperfect.

Scanned PDF OCR:
See scanned_pdf_ocr_results.json for the actual
execution result.

### 7. Prompt Architecture

The system prompt includes:
- Role and objective definition
- Evidence-based evaluation
- Prompt injection precautions
- English and Hinglish handling
- Strict JSON output requirements
- Missing information handling

Few-shot examples were prepared.

### 8. API Reliability

The implementation includes handling for:
- HTTP 429 quota errors
- HTTP 503 service unavailability
- Request timeouts
- Retry with exponential backoff

HTTP 429 stops further requests to avoid wasting quota.

### 9. Preliminary Campus OS Security Scan

A third-party passive scanner reported:

High:
- Missing HTTP Strict Transport Security
- Missing Content Security Policy

Medium:
- Missing X-Frame-Options
- Missing X-Content-Type-Options
- Missing Cross-Origin-Opener-Policy
- Other reported configuration issues

These are scanner findings, not independently
verified vulnerabilities.

### 10. Audit Limitations

- Authorized application-level adversarial testing
  on Campus OS remains pending.
- Hack My Website audit remains pending.
- Missing-skills Gemini test remains pending.
- PDF OCR result must be checked against its
  execution evidence.
- Scanner findings require manual verification.

### 11. Conclusion

The project demonstrates a prototype for structured
AI resume evaluation, Pydantic validation, prompt
architecture, API error handling and OCR extraction.

Further authorized testing and validation are required
before production use.
